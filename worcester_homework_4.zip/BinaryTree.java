
public class BinaryTree<E> {
    private BinaryTreeNode<E> root;
    

    public int height() {
        return heightOfSubtree(root);
    }

    private int heightOfSubtree(BinaryTreeNode<E> node) {
        if (node == null) {
            return 0;
        } else {
            int leftHeight = heightOfSubtree(node.getLeft());
            int rightHeight = heightOfSubtree(node.getRight());

            return Math.max(leftHeight, rightHeight) + 1;
        }
    }

    public void insertIntoShorterSubtree(E new_data) {
        if (root == null) {
            root = new BinaryTreeNode<>(new_data); 
        } else if (root.getLeft() == null) {
            root.setLeft(new BinaryTreeNode<>(new_data));
        } else if (root.getRight() == null) {
            root.setRight(new BinaryTreeNode<>(new_data)); 
        } else {
           
            int leftHeight = heightOfSubtree(root.getLeft());
            int rightHeight = heightOfSubtree(root.getRight());

            if (leftHeight <= rightHeight) {
                insertIntoShorterSubtree(root.getLeft(), new_data); 
            } else {
                insertIntoShorterSubtree(root.getRight(), new_data);
            }
        }
    }

    public boolean isBalanced() {
        return isBalancedRecursive(root) != -1;
    }
    
    private int isBalancedRecursive(BinaryTreeNode<E> node) {
        if (node == null) {
            return 0; 
        }
    
        int leftHeight = isBalancedRecursive(node.getLeft());
        if (leftHeight == -1) {
            return -1;
        }
    
        int rightHeight = isBalancedRecursive(node.getRight());
        if (rightHeight == -1) {
            return -1;
        }
    
        if (Math.abs(leftHeight - rightHeight) > 1) {
            return -1; 
        }
    
        return Math.max(leftHeight, rightHeight) + 1;
    }
    

    private void insertIntoShorterSubtree(BinaryTreeNode<E> node, E new_data) {
        if (node.getLeft() == null) {
            node.setLeft(new BinaryTreeNode<>(new_data));
        } else if (node.getRight() == null) {
            node.setRight(new BinaryTreeNode<>(new_data)); 
            int leftHeight = heightOfSubtree(node.getLeft());
            int rightHeight = heightOfSubtree(node.getRight());

            if (leftHeight <= rightHeight) {
                insertIntoShorterSubtree(node.getLeft(), new_data); 
            } else {
                insertIntoShorterSubtree(node.getRight(), new_data);
            }
        }
    }

    public void insertIntoFirstAvailablePosition(E new_data){
        if (root == null) {
            root = new BinaryTreeNode<>(new_data);
            return;
        }
    
        SinglyLinkedListQueue<BinaryTreeNode<E>> queue = new SinglyLinkedListQueue<>();
        queue.enqueue(root);
    
        while (!queue.isEmpty()) {
            BinaryTreeNode<E> current = queue.dequeue();
    
            if (current.getLeft() == null) {
                current.setLeft(new BinaryTreeNode<>(new_data));
                return;
            } else {
                queue.enqueue(current.getLeft());
            }
    
            if (current.getRight() == null) {
                current.setRight(new BinaryTreeNode<>(new_data));
                return;
            } else {
                queue.enqueue(current.getRight());
            }
        }
    }
  
    public String toString(){
        if (root == null) {
            return "The tree is empty.";
        }
    
        StringBuilder treeString = new StringBuilder();
        SinglyLinkedListQueue<BinaryTreeNode<E>> queue = new SinglyLinkedListQueue<>();
        queue.enqueue(root);
    
        int level = 0;
        int currentLevel = 1;
        int nextLevel = 0;
    
        while (!queue.isEmpty()) {
            BinaryTreeNode<E> current = queue.dequeue();
    
            if (current != null) {
                for (int i = 0; i < level * 4; i++) {
                    treeString.append(" ");
                }
    
                treeString.append("(").append(level).append(") ").append(current.getData()).append("\n");
    
                if (current.getLeft() != null) {
                    queue.enqueue(current.getLeft());
                    nextLevel++;
                } else {
                    queue.enqueue(null);
                }
    
                if (current.getRight() != null) {
                    queue.enqueue(current.getRight());
                    nextLevel++;
                } else {
                    queue.enqueue(null);
                }
    
                currentLevel--;
            
                if (currentLevel == 0) {
                currentLevel = nextLevel;
                    nextLevel = 0;
                    level++;
                }
            }
        }
    
        return treeString.toString();
    }


    public void deleteByPromotingInorderPredecessor(E data) {
        root = deleteRecursiveByPromotingInorderPredecessor(data, root);
    }
    
    private BinaryTreeNode<E> deleteRecursiveByPromotingInorderPredecessor(E data, BinaryTreeNode<E> node) {
        if (node == null) {
            return null;
        }
        if (data.equals(node.getData())) {
            if (node.getLeft() != null && node.getRight() != null) {
                BinaryTreeNode<E> predecessor = findInorderPredecessor(node.getLeft());
                node.setData(predecessor.getData());
                node.setLeft(deleteRecursiveByPromotingInorderPredecessor(predecessor.getData(), node.getLeft()));
            } else {
                node = (node.getLeft() != null) ? node.getLeft() : node.getRight();
            }
        } else if (data.hashCode() < node.getData().hashCode()) {
            node.setLeft(deleteRecursiveByPromotingInorderPredecessor(data, node.getLeft()));
        } else {
            node.setRight(deleteRecursiveByPromotingInorderPredecessor(data, node.getRight()));
        }
        return node;
    }
    
    private BinaryTreeNode<E> findInorderPredecessor(BinaryTreeNode<E> node) {
        while (node.getRight() != null) {
            node = node.getRight();
        }
        return node;
    }
    
    public boolean isBinarySearchTree() {
        return isBinarySearchTree(root, null, null);
    }
    
    private boolean isBinarySearchTree(BinaryTreeNode<E> node, E min, E max) {
        if (node == null) {
            return true;
        }
    
        if ((min != null && node.getData().hashCode() <= min.hashCode()) ||
                (max != null && node.getData().hashCode() >= max.hashCode())) {
            return false;
        }
    
        return isBinarySearchTree(node.getLeft(), min, node.getData()) &&
                isBinarySearchTree(node.getRight(), node.getData(), max);
    }
    
    

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public BinaryTree() {
        root = null;
    }

    public BinaryTree(BinaryTreeNode<E> node) {
        root = node;
    }

    public BinaryTreeNode<E> getRoot() { return root; }
    
    public boolean isEmpty() {
        return root == null;
    }
    
    public void randomInsert(E new_data) {
        BinaryTreeNode<E> new_node = new BinaryTreeNode<E>(new_data);
        if (root == null) {
            root = new_node;
        } else {
            randomInsertRecursive(new_node, root);
        }
    }

    private void randomInsertRecursive(BinaryTreeNode<E> new_node, BinaryTreeNode<E> node) { 
        double r;
        if (node.getLeft() == null) {
            node.setLeft(new_node);
        } else if (node.getRight() == null) {
            node.setRight(new_node);
        } else {
            r = Math.random();
            if (r < 0.5) {
                randomInsertRecursive(new_node, node.getLeft());
            } else {
                randomInsertRecursive(new_node, node.getRight());
            }
        }        
    }

    public void inorderPrint() { inorderPrintRecursive(root); System.out.println(); }
    private void inorderPrintRecursive(BinaryTreeNode<E> node) {
        if (node == null) { return; }
        inorderPrintRecursive(node.getLeft());
        System.out.print(node.getData() + " ");
        inorderPrintRecursive(node.getRight());
    }

    public void preorderPrint() { preorderPrintRecursive(root); System.out.println(); }
    private void preorderPrintRecursive(BinaryTreeNode<E> node) {
        if (node == null) { return; }
        System.out.print(node.getData() + " ");
        preorderPrintRecursive(node.getLeft());
        preorderPrintRecursive(node.getRight());
    }
    
    public void postorderPrint() { postorderPrintRecursive(root); System.out.println(); }
    private void postorderPrintRecursive(BinaryTreeNode<E> node) {
        if (node == null) { return; }
        postorderPrintRecursive(node.getLeft());
        postorderPrintRecursive(node.getRight());
        System.out.print(node.getData() + " ");
    }

    public void breadthFirstPrint() {
    	if (root == null) { return; }
        SinglyLinkedListQueue<BinaryTreeNode<E>> q = new SinglyLinkedListQueue<>();
        q.enqueue(root);
        BinaryTreeNode<E> current_node;
        while (!q.isEmpty()) {
            current_node = q.dequeue();
            System.out.print(current_node.getData() + " ");
            if (current_node.getLeft() != null) { q.enqueue(current_node.getLeft()); }
            if (current_node.getRight() != null) { q.enqueue(current_node.getRight()); }
        }
    }
    
    public void delete(E data) { root = deleteRecursive(data, root); }
    private BinaryTreeNode<E> deleteRecursive(E data, BinaryTreeNode<E> node) {
        BinaryTreeNode<E> current, inorder_successor;
        if (node == null) { return null; }
        node.setLeft(deleteRecursive(data, node.getLeft()));
        node.setRight(deleteRecursive(data, node.getRight()));
        if (data.equals(node.getData())) {
            if (node.getLeft() == null) { return node.getRight(); }
            if (node.getRight() == null) { return node.getLeft(); }
            if (node.getRight().getLeft() == null) {
                node.getRight().setLeft(node.getLeft());
                return node.getRight();
            }
            current = node.getRight();
            while (current.getLeft().getLeft() != null) { current = current.getLeft(); }
            inorder_successor = current.getLeft();
            current.setLeft(inorder_successor.getRight());
            inorder_successor.setLeft(node.getLeft());
            inorder_successor.setRight(node.getRight());
            return inorder_successor;
        }
       return node;
    }
    
    public boolean contains(E data) { return containsRecursive(data, root); }
    private boolean containsRecursive(E data, BinaryTreeNode<E> node) {
    	// Nayan Sawyer
    	if (node == null) {return false;}
    	return data.equals(node.getData()) || containsRecursive(data, node.getLeft()) || 
    			containsRecursive(data, node.getRight());
    }
 
    public int size() {
    	return sizeOfSubtree(root);
    }
    
    private int sizeOfSubtree(BinaryTreeNode<E> root) {
    	// David
    	if (root == null) {
    		return 0;
    	}
    	return 1 + sizeOfSubtree(root.getLeft()) + sizeOfSubtree(root.getRight());
    }
}
