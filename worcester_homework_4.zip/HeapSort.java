public class HeapSort<E extends Comparable<E>> {

    public static <E extends Comparable<E>> void heapSort(E[] arr) {
        int n = arr.length;

        for (int i = n / 2 - 1; i >= 0; i--) {
            int j = i;
            while (true) {
                int leftChild = 2 * j + 1;
                int rightChild = 2 * j + 2;
                int max = j;

                if (leftChild < n && arr[leftChild].compareTo(arr[max]) > 0) {
                    max = leftChild;
                }

                if (rightChild < n && arr[rightChild].compareTo(arr[max]) > 0) {
                    max = rightChild;
                }

                if (max != j) {
                    E tempSwap = arr[j];
                    arr[j] = arr[max];
                    arr[max] = tempSwap;
                    j = max;
                } else {
                    break;
                }
            }
        }

        for (int i = n - 1; i > 0; i--) {
            E temp = arr[0];
            arr[0] = arr[i];
            arr[i] = temp;

            int j = 0;
            while (true) {
                int leftChild = 2 * j + 1;
                int rightChild = 2 * j + 2;
                int max = j;

                if (leftChild < i && arr[leftChild].compareTo(arr[max]) > 0) {
                    max = leftChild;
                }

                if (rightChild < i && arr[rightChild].compareTo(arr[max]) > 0) {
                    max = rightChild;
                }

                if (max != j) {
                    E tempSwap = arr[j];
                    arr[j] = arr[max];
                    arr[max] = tempSwap;
                    j = max;
                } else {
                    break;
                }
            }
        }
    }

    public static void main(String[] args) {
        Integer[] arr = {33, 57, 21, 7, 45, 3, 27, 25, 40, 12};
        
        System.out.println("Original Array:");
        printArray(arr);

        heapSort(arr);

        System.out.println("\nSorted Array:");
        printArray(arr);
    }

    static <E> void printArray(E[] arr) {
        for (E element : arr) {
            System.out.print(element + " ");
        }
        System.out.println();
    }
}
