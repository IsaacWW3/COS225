import java.util.Iterator;
import java.util.NoSuchElementException;

public class SinglyLinkedList<E> implements Iterable<E>{

	private SinglyLinkedListNode<E> head;
    private SinglyLinkedListNode<E> tail;
    private int size;

    
    private class SinglyLinkedListIterator implements Iterator<E> {
        private SinglyLinkedListNode<E> current;
    
        SinglyLinkedListIterator() {
            current = head;
        }
    
        @Override
        public boolean hasNext() {
            return current != null;
        }
    
        @Override
        public E next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            E data = current.getData();
            current = current.getNext();
            return data;
        }
    }
    
    @Override
    public Iterator<E> iterator() {
        return new SinglyLinkedListIterator();
    }
    

    public SinglyLinkedList() {
        head = null;
        tail = null;
        size = 0;
    }
    
    public SinglyLinkedListNode<E> getHead() { return head; }
    
    public SinglyLinkedListNode<E> getTail() { return tail; }
    
    public int size() {
        return size;
    }

    public void addToHead(E new_data) {
        SinglyLinkedListNode<E> new_head = new SinglyLinkedListNode<E>(new_data);
        new_head.setNext(head);
        head = new_head;
        if (tail == null) { tail = new_head; }
        size = size + 1;
    }
    
    public void addToTail(E new_data) {
    	SinglyLinkedListNode<E> new_tail = new SinglyLinkedListNode<E>(new_data);
    	if (tail != null) {
    		tail.setNext(new_tail);
    		tail = new_tail;
    	} else {
    		tail = new_tail;
    		head = new_tail;
    	}
    	size = size + 1;
    }

    public E get(int index) {
    	SinglyLinkedListNode<E> current_node = head;
    	int current_index = 0;
        if ((index >= 0) && (index < size)) {
            while (current_index < index) {
                current_node = current_node.getNext();
                current_index++;
            }
            return current_node.getData();
        }
        throw new java.util.NoSuchElementException("No such element available");
    }

    public void set(int index, E new_data) {
    	SinglyLinkedListNode<E> current_node = head;
        int current_index = 0;
        if ((index >= 0) && (index < size)) {
            while (current_index < index) {
                current_node = current_node.getNext();
                current_index++;
            }
            current_node.setData(new_data);
        } else {
            throw new java.util.NoSuchElementException("Index out of bounds");
        }
    }

    public int search(E data) {
        SinglyLinkedListNode<E> current_node = head;
        int current_index = 0;
        while (current_node != null) {
            if (data.equals(current_node.getData())) {
                return current_index;
            }
            current_node = current_node.getNext();
            current_index++;
         }
         return -1;
    }
    
    public E removeHead() {
        SinglyLinkedListNode<E> node;
        if (head == null) {
            throw new java.util.NoSuchElementException("No such element available");
        }
        node = head;
        head = head.getNext();
        size = size - 1;
        if (head == null) { tail = null; }
        return node.getData();
    }

    public E removeTail() {
        SinglyLinkedListNode<E> node = head;
        E data;
        if (head == null) {
            throw new java.util.NoSuchElementException("No such element available");
        }
        if (head == tail) {
            data = tail.getData();
            head = tail = null;
            size = size - 1;
            return data;
        }
        while (node.getNext() != tail) { node = node.getNext(); }
        data = tail.getData();
        node.setNext(null);
        tail = node;
        size = size - 1;
        return data;
    }
    public void insert(int index, E new_data) {
        if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException("Index out of bounds");
        }
    
        if (index == 0) {
            addToHead(new_data); // If index is 0, add to head
        } else if (index == size) {
            addToTail(new_data); // If index is size, add to tail
        } else {
            SinglyLinkedListNode<E> new_node = new SinglyLinkedListNode<>(new_data);
            SinglyLinkedListNode<E> current_node = head;
            int current_index = 0;
    
            // Traverse the list to the node before the index to insert
            while (current_index < index - 1) {
                current_node = current_node.getNext();
                current_index++;
            }
    
            // Insert the new node in between the current node and the next node
            new_node.setNext(current_node.getNext());
            current_node.setNext(new_node);
            size++;
        }
    }    


    public E remove(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index out of bounds");
        }
    
        SinglyLinkedListNode<E> removedNode;
        if (index == 0) {
            removedNode = head;
            head = head.getNext();
            if (head == null) {
                tail = null;
            }
        } else {
            SinglyLinkedListNode<E> current_node = head;
            int current_index = 0;
    
            // Traverse to the node before the index to remove
            while (current_index < index - 1) {
                current_node = current_node.getNext();
                current_index++;
            }
    
            removedNode = current_node.getNext();
            current_node.setNext(removedNode.getNext());
    
            if (index == size - 1) {
                tail = current_node; // Update tail if removing the last node
            }
        }
        size--;
        return removedNode.getData();
    }
    
}
