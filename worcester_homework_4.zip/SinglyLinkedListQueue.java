public class SinglyLinkedListQueue<E> implements Queue<E> {
    private Node<E> front;
    private Node<E> rear;
    private int size;

    private static class Node<E> {
        E data;
        Node<E> next;

        Node(E element) {
            this.data = element;
            this.next = null;
        }
    }

    public void enqueue(E element) {
        Node<E> newNode = new Node<>(element);
        if (isEmpty()) {
            front = newNode;
            rear = newNode;
        } else {
            rear.next = newNode;
            rear = newNode;
        }
        size++;
    }

    public E dequeue() {
        if (isEmpty()) {
            return null; // Or throw an exception indicating queue underflow
        } else {
            E frontData = front.data;
            front = front.next;
            size--;
            if (front == null) {
                rear = null; // If queue becomes empty after dequeue
            }
            return frontData;
        }
    }

    public E getFront() {
        if (isEmpty()) {
            return null; // Or throw an exception indicating queue is empty
        } else {
            return front.data;
        }
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }
}
