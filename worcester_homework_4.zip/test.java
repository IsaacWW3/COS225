public class test {
    public static void main(String[] args) {
        // Constructing the binary tree
        BinaryTree<Integer> binaryTree = new BinaryTree<>();
        BinaryTreeNode<Integer> root = new BinaryTreeNode<>(8);
        root.setLeft(new BinaryTreeNode<>(3));
        root.setRight(new BinaryTreeNode<>(10));
        root.getLeft().setLeft(new BinaryTreeNode<>(1));
        root.getLeft().setRight(new BinaryTreeNode<>(6));
        root.getLeft().getRight().setLeft(new BinaryTreeNode<>(4));
        root.getLeft().getRight().setRight(new BinaryTreeNode<>(7));
        root.getRight().setRight(new BinaryTreeNode<>(14));
        root.getRight().getRight().setLeft(new BinaryTreeNode<>(13));
        binaryTree = new BinaryTree<>(root);

        // Print the tree using toString
        System.out.println("Tree:");
        System.out.println(binaryTree.toString());

        // Compute its height
        System.out.println("Height: " + binaryTree.height());

        // Check if it is balanced
        System.out.println("Is Balanced? " + binaryTree.isBalanced());

        // Check if it is a binary search tree
        System.out.println("Is Binary Search Tree? " + binaryTree.isBinarySearchTree());

        // Insert 0 into the tree using insertIntoShorterSubtree
        binaryTree.insertIntoShorterSubtree(0);

        // Insert 9 into the tree using insertIntoFirstAvailablePosition
        binaryTree.insertIntoFirstAvailablePosition(9);

        // Delete 8 from the tree using deleteByPromotingInorderPredecessor
        binaryTree.deleteByPromotingInorderPredecessor(8);

        // Print the updated tree using toString
        System.out.println("Tree after operations:");
        System.out.println(binaryTree.toString());
    }

}


